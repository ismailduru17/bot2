import pandas as pd

def export_to_csv(results_df, filename='strategy_report.csv'):
    results_df.to_csv(filename, index=False)
    print(f"CSV olarak kaydedildi: {filename}")

def export_to_pdf(results_df, filename='strategy_report.pdf'):
    from matplotlib.backends.backend_pdf import PdfPages
    import matplotlib.pyplot as plt

    with PdfPages(filename) as pdf:
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.axis('tight')
        ax.axis('off')
        table = ax.table(cellText=results_df.values, colLabels=results_df.columns, loc='center')
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        table.scale(1.2, 1.2)
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()
    print(f"PDF olarak kaydedildi: {filename}")