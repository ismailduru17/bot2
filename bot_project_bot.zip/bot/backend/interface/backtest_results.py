import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from backend.backtest.backtest_engine import simulate_grid_strategy, evaluate_performance

# Örnek veri yükleyici
def load_sample_data():
    df = pd.read_csv("sample_ohlcv.csv")
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    return df

def render_backtest_results():
    st.title("Backtest Sonuçları")

    df = load_sample_data()
    entry_price = df['close'].iloc[-30]
    grid_positions = simulate_grid_strategy(df, entry_price, grid_size=10, grid_count=5)
    results = evaluate_performance(grid_positions)

    st.subheader("Pozisyonlar")
    st.dataframe(results)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df['timestamp'], y=df['close'], mode='lines', name='Fiyat'))

    for _, row in results.iterrows():
        fig.add_trace(go.Scatter(
            x=[row['time']], y=[row['entry']],
            mode='markers+text',
            marker=dict(color='green', size=10),
            name=f"Grid {row['grid']}",
            text=[f"G{row['grid']}"],
            textposition="bottom center"
        ))

    fig.update_layout(title='Backtest Grid Pozisyonları', xaxis_title='Zaman', yaxis_title='Fiyat')
    st.plotly_chart(fig)

if __name__ == "__main__":
    render_backtest_results()