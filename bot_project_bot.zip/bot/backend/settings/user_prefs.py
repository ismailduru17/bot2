import json
import os

PREFS_FILE = "user_preferences.json"

def save_preferences(prefs):
    with open(PREFS_FILE, "w") as f:
        json.dump(prefs, f, indent=2)

def load_preferences():
    if not os.path.exists(PREFS_FILE):
        return {}
    with open(PREFS_FILE, "r") as f:
        return json.load(f)