import unittest
from backend.backtest.backtest_engine import simulate_grid_strategy, evaluate_performance
from backend.scanner.market_opportunity import fetch_top_movers

class TestStrategy(unittest.TestCase):

    def test_simulate_grid_strategy(self):
        # Test verisi
        df = pd.read_csv("sample_ohlcv.csv")
        entry_price = 100.0
        grid_size = 10.0
        grid_count = 5
        direction = 'long'
        
        # Simülasyon çalıştır
        positions = simulate_grid_strategy(df, entry_price, grid_size, grid_count, direction)
        
        # Performans test edilmesi
        self.assertGreater(len(positions), 0, "Pozisyon bulunamadı.")
    
    def test_evaluate_performance(self):
        # Test verisi
        positions = [
            {'grid_level': 1, 'price': 100.0, 'hit_time': '2021-10-01'},
            {'grid_level': 2, 'price': 110.0, 'hit_time': '2021-10-02'}
        ]
        
        # Performans değerlendirmesi
        results = evaluate_performance(positions, tp_perc=1.5, sl_perc=1.0)
        
        # Sonuçların kontrol edilmesi
        self.assertEqual(len(results), 2, "Test sonuçları eksik.")
    
    def test_fetch_top_movers(self):
        api_key = "test_api_key"
        api_secret = "test_api_secret"
        
        opportunities = fetch_top_movers(api_key, api_secret)
        
        # Opportunities kontrolü
        self.assertGreater(len(opportunities), 0, "Market fırsatları bulunamadı.")

if __name__ == "__main__":
    unittest.main()