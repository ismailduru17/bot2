import firebase_admin
from firebase_admin import messaging, credentials

# Firebase Admin SDK'yı başlat
cred = credentials.Certificate('path/to/serviceAccountKey.json')
firebase_admin.initialize_app(cred)

def send_notification(fcm_token, title, body):
    message = messaging.Message(
        notification=messaging.Notification(
            title=title,
            body=body,
        ),
        token=fcm_token,
    )
    
    try:
        response = messaging.send(message)
        print('Bildirim gönderildi:', response)
    except Exception as e:
        print('Bildirim gönderilemedi:', e)