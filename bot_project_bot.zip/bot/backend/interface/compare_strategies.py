import streamlit as st
import pandas as pd
import plotly.graph_objects as go

def load_strategy_results():
    # Örnek veri
    return pd.DataFrame([
        {'isim': 'Strateji A', 'karlilik': 12.4, 'risk': 3.1, 'isabet': 67},
        {'isim': 'Strateji B', 'karlilik': 18.9, 'risk': 4.8, 'isabet': 72},
        {'isim': 'Strateji C', 'karlilik': 9.2, 'risk': 2.6, 'isabet': 60},
    ])

def render_strategy_comparison():
    st.title("Strateji Karşılaştırma Analizi")

    df = load_strategy_results()
    st.dataframe(df.set_index('isim'))

    fig = go.Figure()
    fig.add_trace(go.Bar(name='Kârlılık (%)', x=df['isim'], y=df['karlilik']))
    fig.add_trace(go.Bar(name='Risk (%)', x=df['isim'], y=df['risk']))
    fig.add_trace(go.Bar(name='İsabet Oranı (%)', x=df['isim'], y=df['isabet']))

    fig.update_layout(barmode='group', title='Stratejilerin Performans Kıyaslaması')
    st.plotly_chart(fig)

if __name__ == "__main__":
    render_strategy_comparison()