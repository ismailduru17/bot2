import argparse

def main():
    parser = argparse.ArgumentParser(description="Trade CLI")
    parser.add_argument("--hello", action="store_true", help="Test komutu")
    args = parser.parse_args()
    if args.hello:
        print("Merhaba, CLI çalışıyor!")

if __name__ == "__main__":
    main()