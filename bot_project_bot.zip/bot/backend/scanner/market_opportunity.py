from binance.client import Client
from datetime import datetime, timedelta

def fetch_top_movers(api_key, api_secret):
    client = Client(api_key, api_secret)
    tickers = client.futures_ticker()
    usdt_pairs = [t for t in tickers if t['symbol'].endswith('USDT')]
    top_volatiles = sorted(usdt_pairs, key=lambda x: abs(float(x['priceChangePercent'])), reverse=True)[:20]
    return top_volatiles

def fetch_price_change_history(client, symbol):
    now = datetime.utcnow()
    intervals = {
        '1d': now - timedelta(days=1),
        '1w': now - timedelta(weeks=1),
        '1mo': now - timedelta(days=30)
    }
    result = {}
    for label, since in intervals.items():
        candles = client.futures_klines(symbol=symbol, interval='1d', limit=30)
        if candles:
            open_price = float(candles[0][1])
            close_price = float(candles[-1][4])
            change = ((close_price - open_price) / open_price) * 100
            result[label] = round(change, 2)
    return result