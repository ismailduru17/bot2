import pandas as pd

def detect_bos(df):
    # Break of structure - fiyat önceki yüksekliği kırarsa
    bos = df['high'].iloc[-1] > df['high'].iloc[-2]
    return bos

def detect_fvg(df):
    # Fair Value Gap tespiti: mumlar arası boşluk varsa
    gaps = []
    for i in range(2, len(df)):
        if df['low'].iloc[i] > df['high'].iloc[i-2]:
            gaps.append(df.iloc[i])
    return gaps

def detect_engulfing(df):
    prev = df.iloc[-2]
    curr = df.iloc[-1]
    return curr['close'] > curr['open'] and prev['close'] < prev['open'] and curr['close'] > prev['open']

def detect_pinbar(df):
    last = df.iloc[-1]
    body = abs(last['open'] - last['close'])
    tail = last['high'] - max(last['open'], last['close'])
    return tail > body * 2

def analyze_formations(df):
    signals = {
        'bos': detect_bos(df),
        'fvg': len(detect_fvg(df)) > 0,
        'engulfing': detect_engulfing(df),
        'pinbar': detect_pinbar(df)
    }
    return signals