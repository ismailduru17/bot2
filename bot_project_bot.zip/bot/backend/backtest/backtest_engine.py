import pandas as pd

def simulate_grid_strategy(df, entry_price, grid_size, grid_count, direction='long'):
    positions = []
    for i in range(grid_count):
        level_price = entry_price + (i * grid_size if direction == 'long' else -i * grid_size)
        hit = df[(df['low'] <= level_price) & (df['high'] >= level_price)]
        if not hit.empty:
            positions.append({
                'grid_level': i + 1,
                'price': level_price,
                'hit_time': hit.iloc[0]['timestamp']
            })
    return positions

def evaluate_performance(positions, tp_perc=1.5, sl_perc=1.0):
    result = []
    for pos in positions:
        tp = pos['price'] * (1 + tp_perc / 100)
        sl = pos['price'] * (1 - sl_perc / 100)
        result.append({
            'entry': pos['price'],
            'tp': round(tp, 2),
            'sl': round(sl, 2),
            'grid': pos['grid_level'],
            'time': pos['hit_time']
        })
    return pd.DataFrame(result)