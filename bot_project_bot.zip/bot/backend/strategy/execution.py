from binance.client import Client
from db.init_db import SessionLocal
from db.models import Trade
from auth.auth_utils import decode_access_token
import os

# Emir gönderici sınıfı
class TradeExecutor:
    def __init__(self, api_key, api_secret, testnet=True):
        self.client = Client(api_key, api_secret)
        if testnet:
            self.client.API_URL = 'https://testnet.binancefuture.com/fapi'

    def open_position(self, symbol, side, qty, sl=None, tp=None):
        order = self.client.futures_create_order(
            symbol=symbol,
            side=side,
            type='MARKET',
            quantity=qty
        )
        print("Açık pozisyon:", order)
        return order

    def close_position(self, symbol, side, qty):
        return self.client.futures_create_order(
            symbol=symbol,
            side=side,
            type='MARKET',
            quantity=qty
        )