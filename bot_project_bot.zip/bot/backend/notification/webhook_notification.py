import requests
import json

def send_webhook(url, data):
    headers = {'Content-Type': 'application/json'}
    try:
        response = requests.post(url, json=data, headers=headers)
        if response.status_code == 200:
            print('Webhook başarıyla gönderildi.')
        else:
            print(f"Webhook hatası: {response.status_code}")
    except Exception as e:
        print('Webhook gönderilemedi:', e)