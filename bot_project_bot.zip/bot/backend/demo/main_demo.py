import streamlit as st
from backend.strategy.history import save_strategy, load_history
from backend.backtest.backtest_engine import simulate_grid_strategy, evaluate_performance
from backend.scanner.market_opportunity import fetch_top_movers
from backend.report.generate_report import export_to_csv, export_to_pdf

def demo_backtest():
    st.subheader("Backtest Simülasyonu")
    entry_price = st.number_input("Giriş Fiyatı", value=100.0)
    grid_size = st.number_input("Grid Aralığı", value=10.0)
    grid_count = st.slider("Grid Sayısı", 1, 10, 5)
    tp_perc = st.slider("Take Profit (%)", 0.5, 5.0, 1.5)
    sl_perc = st.slider("Stop Loss (%)", 0.5, 5.0, 1.0)
    direction = st.selectbox("Yön", ["long", "short"])
    
    if st.button("Simülasyonu Başlat"):
        df = pd.read_csv("sample_ohlcv.csv")
        positions = simulate_grid_strategy(df, entry_price, grid_size, grid_count, direction)
        results = evaluate_performance(positions, tp_perc, sl_perc)
        st.dataframe(results)
        export_to_csv(results)
        export_to_pdf(results)

def demo_market_opportunity():
    st.subheader("Market Fırsatları")
    api_key = st.text_input("API Anahtarı")
    api_secret = st.text_input("API Secret", type="password")
    if st.button("Fırsatları Göster"):
        opportunities = fetch_top_movers(api_key, api_secret)
        st.write(opportunities)

def demo_history():
    st.subheader("Geçmiş Strateji Yönetimi")
    history = load_history()
    st.write(history)

def main():
    st.title("Aklı Yatırım Demo Paneli")
    
    demo_option = st.sidebar.selectbox("Demo Seçeneği", ["Backtest", "Market Fırsatları", "Strateji Geçmişi"])
    
    if demo_option == "Backtest":
        demo_backtest()
    elif demo_option == "Market Fırsatları":
        demo_market_opportunity()
    elif demo_option == "Strateji Geçmişi":
        demo_history()

if __name__ == "__main__":
    main()