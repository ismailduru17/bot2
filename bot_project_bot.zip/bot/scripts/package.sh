#!/bin/bash
rm -rf ../dist
mkdir -p ../dist
zip -r ../dist/bot_full.zip . -x "*.venv*" "*.git*" "__pycache__/*"