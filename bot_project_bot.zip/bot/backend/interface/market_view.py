import streamlit as st
import pandas as pd
from binance.client import Client
from datetime import datetime, timedelta

# Binance client test verisiyle initialize edilmeli
client = Client()

def fetch_price_change_history(symbol):
    candles = client.futures_klines(symbol=symbol, interval='1d', limit=30)
    if candles:
        open_price = float(candles[0][1])
        close_price = float(candles[-1][4])
        change_1d = ((close_price - open_price) / open_price) * 100

        week_open = float(candles[-7][1])
        week_change = ((close_price - week_open) / week_open) * 100

        month_open = float(candles[0][1])
        month_change = ((close_price - month_open) / month_open) * 100

        return {
            "1 Gün": round(change_1d, 2),
            "1 Hafta": round(week_change, 2),
            "1 Ay": round(month_change, 2)
        }
    return {}

def main():
    st.title("Piyasa Tarayıcı – Hareketli Coinler")
    symbols = ["BTCUSDT", "ETHUSDT", "XRPUSDT", "SOLUSDT", "DOGEUSDT"]
    data = []
    for sym in symbols:
        changes = fetch_price_change_history(sym)
        row = {"Coin": sym}
        row.update(changes)
        data.append(row)

    df = pd.DataFrame(data)
    st.dataframe(df.set_index("Coin"))

if __name__ == "__main__":
    main()