import json
import os

HISTORY_FILE = "strategy_history.json"

def save_strategy(params):
    history = load_history()
    history.append(params)
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)

def load_history():
    if not os.path.exists(HISTORY_FILE):
        return []
    with open(HISTORY_FILE, "r") as f:
        return json.load(f)

def clear_history():
    with open(HISTORY_FILE, "w") as f:
        json.dump([], f)