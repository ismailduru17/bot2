import streamlit as st
from backend.backtest.backtest_engine import simulate_grid_strategy, evaluate_performance
import pandas as pd

def load_sample_data():
    df = pd.read_csv("sample_ohlcv.csv")
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    return df

def render_strategy_form():
    st.title("Strateji Parametre Girişi ve Simülasyon")

    with st.form("strategy_form"):
        entry_price = st.number_input("Giriş Fiyatı", value=100.0)
        grid_size = st.number_input("Grid Aralığı", value=10.0)
        grid_count = st.slider("Grid Sayısı", 1, 10, 5)
        tp_perc = st.slider("Take Profit (%)", 0.5, 5.0, 1.5)
        sl_perc = st.slider("Stop Loss (%)", 0.5, 5.0, 1.0)
        direction = st.selectbox("Yön", ["long", "short"])
        submitted = st.form_submit_button("Simülasyonu Başlat")

    if submitted:
        df = load_sample_data()
        positions = simulate_grid_strategy(df, entry_price, grid_size, grid_count, direction)
        results = evaluate_performance(positions, tp_perc, sl_perc)
        st.success(f"{len(results)} pozisyon simüle edildi.")
        st.dataframe(results)

if __name__ == "__main__":
    render_strategy_form()