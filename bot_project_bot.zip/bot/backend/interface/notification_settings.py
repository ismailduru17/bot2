import streamlit as st
from backend.settings.user_prefs import load_preferences, save_preferences

def render_notification_settings():
    st.title("Bildirim Ayarları")

    # Kullanıcı ayarlarını yükle
    prefs = load_preferences()
    fcm_token = prefs.get('fcm_token', '')
    webhook_url = prefs.get('webhook_url', '')

    # Firebase token ve webhook URL ayarları
    fcm_token_input = st.text_input("Firebase Cloud Messaging (FCM) Token", value=fcm_token)
    webhook_url_input = st.text_input("Webhook URL", value=webhook_url)

    # Ayarları kaydet
    if st.button("Ayarları Kaydet"):
        new_prefs = {
            'fcm_token': fcm_token_input,
            'webhook_url': webhook_url_input
        }
        save_preferences(new_prefs)
        st.success("Bildirim ayarları kaydedildi.")

if __name__ == "__main__":
    render_notification_settings()